# Pyarmor 9.1.2 (trial), 000000, 2025-10-09T13:31:57.135703
from .pyarmor_runtime import __pyarmor__
